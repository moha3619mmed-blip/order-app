# POS Smart — بناء APK من الهاتف

1. ارفع مجلد المشروع إلى GitHub كمستودع جديد.
2. افتح تبويب Actions.
3. اختر **Build POS Smart APK**.
4. اضغط **Run workflow**.
5. بعد اكتمال البناء، افتح نتيجة التشغيل ثم Artifacts.
6. نزّل `POS-Smart-debug-apk.zip` واستخرج `app-debug.apk` وثبّته على الهاتف.

المشروع يحتوي WebView والتطبيق يعمل بدون إنترنت بعد التثبيت، ويضم ملف POS داخل assets.
